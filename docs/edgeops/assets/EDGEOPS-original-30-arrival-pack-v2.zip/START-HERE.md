# EDGEOPS hardware arrival pack

Preparation only. The owner reports the same 30 selected products ordered; receipt,
inspection, calibration, connection and production acceptance remain unverified.
The owner reports partial receipt; the complete set and exact received variants
remain unconfirmed. No individual item is marked received from that report alone.
No substitutions or additional hardware are authorized by this pack.

1. Keep power disconnected. Open receipt-worksheet.csv and record the actual
   received model, board revision, label/photo references and unresolved issues.
   Blank fields mean unverified. P26-P29 keep their optional installation roles;
   P30 remains a cold spare. All 30 items are retained, not all are wired together.
2. Read phase-01-hardware/docs/physical-connection-pack/README.md and its printable
   connection-guide.html. Sensor wiring is conditional on actual board checks.
   Motor-power wiring and control remain pending exact ordered-part review.
3. Read phase-01-hardware/docs/OFFLINE_CAPTURE_HANDOFF.md. This contains the software
   commands and exit-code meanings. Python 3.12+ is needed for the complete suite.
   The included example is synthetic and opens no hardware port.
   Version two includes scripts/summarize_capture.py and its tests under
   phase-01-hardware, plus validation/FIRST-HARDWARE-ACCEPTANCE.md. Read the H1
   checklist before planning a run. Summary statistics do not close physical checks.
   Links to wider production-design context require the full reviewed repository.
4. Firmware source and PlatformIO configuration are included for the existing
   ESP32 target. Dependency installation, compilation and upload are separate
   steps; this download does not establish a successful build or exact-board fit.
   See phase-01-hardware/docs/FIRMWARE_BUILD.md for compile-only instructions.
5. To run offline software checks after installing test dependencies, use the
   commands in the handoff guide from phase-01-hardware. No hardware is needed.

The receipt worksheet is an offline working copy. Editing it does not update the
dashboard, verify purchases, enroll devices or authorize equipment. Capture files
and credentials from your computer are never included in this export.

Before extraction, use a reviewed repository copy of the standard-library-only
checker from the dashboard directory:

    python verify_arrival_pack.py edgeops-hardware-arrival-pack.zip

It reads the ZIP without extracting or running anything, checks every manifest
file hash/size and the fixed-30 plan/matrix/map/blank-worksheet relationships, and
prints JSON. Exit 0 means internal file consistency passed; exit 2 means the
archive was unavailable, damaged or unsupported. It does not modify any file,
contact a service or access hardware. The archive includes a copy at
dashboard/verify_arrival_pack.py for convenience, but an untrusted archive's own
checker is not a trust anchor. Use an independently reviewed copy. Keep the
original ZIP unchanged and edit a separate worksheet copy after receipt.

The dashboard Hardware workspace can preview that separate CSV working copy
locally without uploading or storing it. Keep the original planning fields and
all 30 rows unchanged. Use YYYY-MM-DD for declared dates, and Record status
awaiting-delivery-unverified or owner-notes-unverified. The preview and its JSON
export retain owner declarations as unverified; they do not register physical
receipt, approve compatibility or authorize equipment.

manifest.json lists file sizes and SHA-256 hashes for corruption checks. It is
not a signature, trusted release, proof of origin or physical acceptance. Verify
sources against the reviewed repository before use. All physical readiness flags
remain false. Do not bypass the dashboard's synthetic-only ingestion boundary.
